<?php
if (!defined('ABSPATH')) exit; // Exit if accessed directly
if (!is_admin()) {
	die('Permission Denied!');
}
	echo "here";
