<?php
	//********************************************************************
	//Kelkoo categories
	//Music
	//2015-01 Calv
	//********************************************************************

	$this->addAttributeMapping('', 'music-artist', true, false);
	$this->addAttributeMapping('', 'music-media', true, false);
	$this->addAttributeMapping('', 'music-genre', true, false);
	//$this->addAttributeMapping('', '', true, false);
?>