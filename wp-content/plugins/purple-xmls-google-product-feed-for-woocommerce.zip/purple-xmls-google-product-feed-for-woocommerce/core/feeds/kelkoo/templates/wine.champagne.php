<?php
	//********************************************************************
	//Kelkoo categories
	//Wine and Champagne
	//2015-01 Calv
	//********************************************************************

	$this->addAttributeMapping('', 'wine-country', true, false); //origin of wine
	$this->addAttributeMapping('', 'wine-year', true, false); //year of production
	$this->addAttributeMapping('', 'wine-capacity', true, false);
	//$this->addAttributeMapping('', '', true, false);
?>