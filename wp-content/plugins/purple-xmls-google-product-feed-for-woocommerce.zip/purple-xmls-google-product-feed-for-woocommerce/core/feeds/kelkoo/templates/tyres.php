<?php
	//********************************************************************
	//Kelkoo categories
	//Tyres
	//2015-01 Calv
	//********************************************************************

	//both attributes are highly recommended
	$this->addAttributeMapping('', 'tyre-wet-grip', true, false); 
	$this->addAttributeMapping('', 'tyre-noise-class', true, false);
	//$this->addAttributeMapping('', '', true, false);
	//$this->addAttributeMapping('', '', true, false);
?>