<?php
if (!defined('ABSPATH')) exit; // Exit if accessed directly
  /********************************************************************
  Version 2.0
    A Feed for Products by Category
		This gets a little complex. See design-document -> ProductCategoryExport
	  Copyright 2014 Purple Turtle Productions. All rights reserved.
		license	GNU General Public License version 3 or later; see GPLv3.txt
	By: Keneto 2014-05-08
	2014-07-27 This Feed Provider Deprecated
  ********************************************************************/

class PCategoryProductsFeed {

	function getFeedData() {
		//PCategoryProductsFeed no longer exists
	}
}
