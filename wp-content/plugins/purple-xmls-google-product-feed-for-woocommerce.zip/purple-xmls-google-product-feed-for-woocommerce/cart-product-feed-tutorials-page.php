<?php
if (!defined('ABSPATH')) exit; // Exit if accessed directly

/**
 * Created by PhpStorm.
 * User: subash
 * Date: 10/18/16
 * Time: 5:50 PM
 */
?>

<div class="cpf_tutorials_page" style="margin-top: 59px;">
    <div class="cpf_google_merchant_tutorials">
        <h2> ExportFeed : Google Merchant Feed Creation Tutorial</h2>
    </div>
    <?php $embed_code = wp_oembed_get('https://www.youtube.com/watch?v=BDubND7fvHE');
    echo $embed_code;
    ?>
</div>
