/**
 * Isolating Select2
 */

var RP_Select2 = jQuery.fn.select2;
