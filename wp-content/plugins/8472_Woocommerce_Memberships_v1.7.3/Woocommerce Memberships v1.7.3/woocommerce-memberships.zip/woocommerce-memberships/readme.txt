=== WooCommerce Memberships ===
Author: woothemes, skyverge
Tags: woocommerce
Requires at least: 4.1
Tested up to: 4.6.1
Requires WooCommerce at least: 2.4.13
Tested WooCommerce up to: 2.6.8

See http://docs.woothemes.com/document/woocommerce-memberships/ for full documentation.

== Installation ==

1. Upload the entire 'woocommerce-memberships' folder to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress
